import java.io.*;

class C08EX01 {

  public static void main(String args[]) { 
    System.out.println("Execucao do programa principal - 1");
    SubRotina();
    System.out.println("Execucao do programa principal - 2");
  }

  public static void SubRotina() {
    System.out.println("Execucao da sub-rotina");
  }

}
