public class Tfilho extends Tpai {

  protected void Executa() {
    System.out.println("Acao executada na classe-filho");
  }

}
