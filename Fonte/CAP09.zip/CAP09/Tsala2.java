abstract class Tsala2 {
  protected int SALA;
}
