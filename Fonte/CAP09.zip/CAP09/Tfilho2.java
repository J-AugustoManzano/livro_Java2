class Tfilho2 implements Tpai2, Tmae2 {

  public String olhos() { 
    return("claros");
  }

  public String cabelos() { 
    return("cacheados");
  }

}
