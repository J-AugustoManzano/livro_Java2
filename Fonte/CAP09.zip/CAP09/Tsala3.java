abstract class Tsala3 {
  int SALA;

  Tsala3() {}
  protected void finalize() {}

}
