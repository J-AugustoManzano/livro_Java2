public interface Tpai2 {
  public abstract String olhos();
}

