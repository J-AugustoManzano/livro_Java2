public class Taluno {
  String NOME;
  float MEDIA;
}
