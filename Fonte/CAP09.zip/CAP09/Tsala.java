abstract class Tsala {
  int SALA;
}
