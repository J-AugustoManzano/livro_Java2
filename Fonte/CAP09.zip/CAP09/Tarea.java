public class Tarea {

  public static long Area(int X) {
    long AREA = X * X;
    return(AREA);
  }

  public static double Area(float R, float H) {
    double AREA = R * R * 3.14159 * H;
    return(AREA);
  }

  public static int Area(int X, int Y, int Z) {
    int AREA = X * Y * Z;
    return(AREA);
  }

}
