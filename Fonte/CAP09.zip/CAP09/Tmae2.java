public interface Tmae2 {
  public abstract String cabelos();
}
