public class Tpai {

  protected void Executa() {
    System.out.println("Acao executada na classe-pai");
  }

}
