import java.io.*;

public class C09EX14 {
  public static void main(String args[]) {

    Tfilho2 PROLE = new Tfilho2();    

    System.out.println("O filho possui olhos " + PROLE.olhos());
    System.out.println("O filho possui cabelos " + PROLE.cabelos());

  }
}
