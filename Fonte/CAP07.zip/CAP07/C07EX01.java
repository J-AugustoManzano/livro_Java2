class C07EX01 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.acos(-1));                  
    System.out.println(Math.acos(1));    
    System.out.println(Math.acos(0.5)); 
    System.out.println(Math.acos(0.5) * 180 / Math.PI); 
    System.out.println(Math.toDegrees(Math.acos(0.5))); 

  }
}

