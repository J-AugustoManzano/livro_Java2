class C07EX27 {
  public static void main(String args[]) {

   String TEXTO = "Computador";

   System.out.println(TEXTO.substring(0, 3)); 
   System.out.println(TEXTO.substring(3, 7)); 
   System.out.println(TEXTO.substring(7, 10)); 

  }
}
