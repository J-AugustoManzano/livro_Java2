class C07EX07 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.tan(4));                  
    System.out.println(Math.tan(Math.PI / 4));    
    System.out.println(Math.tan(45 * Math.toRadians(1)));
    System.out.println(Math.tan(Math.PI / 7)); 

  }
}

