import java.io.*;
class C07EX55 {
  public static void main(String args[]) {

    String STR = "10";
    float VALOR;

    VALOR = Float.valueOf(STR).floatValue();

    System.out.println();
    System.out.print("Valor = " + VALOR);
    System.out.println();
    
  }
}
