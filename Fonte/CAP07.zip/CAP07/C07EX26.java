class C07EX26 {
  public static void main(String args[]) {

   String TEXTO = "Programacao com Java";

   System.out.println(TEXTO.replace('a', 'e')); 

  }
}
