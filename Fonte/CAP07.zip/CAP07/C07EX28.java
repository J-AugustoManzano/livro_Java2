class C07EX28 {
  public static void main(String args[]) {

   String TEXTO = "Programacao com Java";

   System.out.println(TEXTO. toLowerCase()); 
   System.out.println(TEXTO. toUpperCase()); 

  }
}
