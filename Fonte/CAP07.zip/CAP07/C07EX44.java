import java.io.*;
class C07EX44 {
  public static void main(String args[]) {

    double VALOR = 23.78976;
    String STR;

    STR = Double.toString(VALOR);

    System.out.println();
    System.out.print("Valor = " + STR);
    System.out.println();
    
  }
}
