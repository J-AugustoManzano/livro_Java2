class C07EX25 {
  public static void main(String args[]) {

   String TEXTO = "Programacao com Java";
   int TAMANHO = TEXTO.length();

   System.out.println(TAMANHO); 

  }
}
