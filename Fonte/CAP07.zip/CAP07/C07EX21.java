class C07EX21 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.round(5.8));                  
    System.out.println(Math.round(5.2));    

  }
}
