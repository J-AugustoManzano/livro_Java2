import java.io.*;
class C07EX58 {
  public static void main(String args[]) {

    String STR = "10";
    byte CURTO;

    CURTO = Byte.valueOf(STR).byteValue();

    System.out.println();
    System.out.print("Valor = " + CURTO);
    System.out.println();
    
  }
}
