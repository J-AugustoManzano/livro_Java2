import java.io.*;
class C07EX45 {
  public static void main(String args[]) {

    float VALOR = 35;
    String STR;

    STR = Float.toString(VALOR);

    System.out.println();
    System.out.print("Valor = " + STR);
    System.out.println();
    
  }
}
