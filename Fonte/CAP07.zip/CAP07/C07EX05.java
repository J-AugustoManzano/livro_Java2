class C07EX05 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.cos(60 * Math.PI / 180));                  
    System.out.println(Math.cos(60 * Math.toRadians(1)));                  
    System.out.println(Math.cos(45 * Math.PI / 180));    
    System.out.println(Math.cos(Math.atan(1))); 
    System.out.println(Math.cos(Math.PI / 3)); 

  }
}

                