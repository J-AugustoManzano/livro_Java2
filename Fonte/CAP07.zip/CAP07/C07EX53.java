import java.io.*;
class C07EX53 {
  public static void main(String args[]) {

    byte CURTO = 10;
    String STR;

    STR = Byte.toString(CURTO);

    System.out.println();
    System.out.print("Valor = " + STR);
    System.out.println();
    
  }
}
