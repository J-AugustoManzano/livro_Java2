import java.io.*;
class C07EX60 {
  public static void main(String args[]) {

    int INTEIRO = 0;
    boolean LOGICO;

    LOGICO = INTEIRO != 0;

    System.out.println();
    System.out.println("Valor verdadeiro de INTEIRO ..: " + INTEIRO);
    System.out.println("Valor verdadeiro de LOGICO ...: " + LOGICO);
    System.out.println();
    
  }
}
