class C07EX13 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.ceil(2.03));                  
    System.out.println(Math.ceil(-2.03));    

  }
}

