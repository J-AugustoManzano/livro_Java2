import java.io.*;
class C07EX52 {
  public static void main(String args[]) {

    long LONGO = 10;
    String STR;

    STR = Long.toString(LONGO);

    System.out.println();
    System.out.print("Valor = " + STR);
    System.out.println();
    
  }
}
