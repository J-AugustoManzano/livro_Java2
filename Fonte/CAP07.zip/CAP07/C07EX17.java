class C07EX17 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.min(18.7,4.3));                  
    System.out.println(Math.min(10,3));    

  }
}


