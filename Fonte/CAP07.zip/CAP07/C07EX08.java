class C07EX08 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.pow(2,3));                  
    System.out.println(Math.pow(2,0));                  
    System.out.println(Math.pow(10,0));                  
    System.out.println(Math.pow(-2,3));                  
    System.out.println(Math.pow(2,-3));
  }
}

