class C07EX20 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.rint(18.7));                  
    System.out.println(Math.rint(10.3));    

  }
}
