class C07EX15 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.IEEEremainder(18.7,4.3));                  
    System.out.println(Math.IEEEremainder(10.0,3.0));    

  }
}

