import java.io.*;
class C07EX48 {
  public static void main(String args[]) {

    char CARACTERE = 'A';
    int INTEIRO;

    INTEIRO = (int)CARACTERE; 

    System.out.println();
    System.out.print("Valor = " + INTEIRO);
    System.out.println();
    
  }
}
