import java.io.*;
class C07EX57 {
  public static void main(String args[]) {

    String STR = "10";
    long LONGO;

    LONGO = Long.valueOf(STR).longValue();

    System.out.println();
    System.out.print("Valor = " + LONGO);
    System.out.println();
    
  }
}
