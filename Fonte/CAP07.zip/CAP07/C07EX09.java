class C07EX09 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.sqrt(9.0));                  
    System.out.println(Math.sqrt(2.0));                  
    System.out.println(Math.sqrt(144));                  
    System.out.println(Math.sqrt(Math.sqrt(16)));                  

  }
}

