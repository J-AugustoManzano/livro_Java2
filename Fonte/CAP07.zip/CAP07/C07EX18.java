class C07EX18 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.random());                  
    System.out.println(Math.random() * 10);    

  }
}
