class C07EX10 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.exp(3.4));                  
    System.out.println(Math.exp(1));                  

  }
}

