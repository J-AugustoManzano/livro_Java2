import java.io.*;
class C07EX54 {
  public static void main(String args[]) {

    String STR = "10.89";
    double VALOR;

    VALOR = Double.valueOf(STR).doubleValue();

    System.out.println();
    System.out.print("Valor = " + VALOR);
    System.out.println();
    
  }
}
