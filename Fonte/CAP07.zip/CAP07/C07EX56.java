import java.io.*;
class C07EX56 {
  public static void main(String args[]) {

    String STR = "10";
    int INTEIRO;

    INTEIRO = Integer.valueOf(STR).intValue();

    System.out.println();
    System.out.print("Valor = " + INTEIRO);
    System.out.println();
    
  }
}
