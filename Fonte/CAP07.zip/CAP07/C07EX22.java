class C07EX22 {
  public static void main(String args[]) {

    String TEXTO = "Programacao com Java";

    System.out.println();
    System.out.println(TEXTO.charAt(16));                  

  }
}
