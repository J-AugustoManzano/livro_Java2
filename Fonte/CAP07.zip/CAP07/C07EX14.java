class C07EX14 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.floor(2.03));                  
    System.out.println(Math.floor(-2.03));    

  }
}

