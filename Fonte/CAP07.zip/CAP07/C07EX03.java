class C07EX03 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.atan(1));                  
    System.out.println(Math.atan(0.5));    
    System.out.println(Math.toDegrees(Math.atan(1)));  
    System.out.println(Math.atan(2)); 

  }
}

