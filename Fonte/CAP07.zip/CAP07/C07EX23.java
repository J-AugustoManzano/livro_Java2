class C07EX23 {
  public static void main(String args[]) {

   String TEXTO1 = "Ola ";
   String TEXTO2 = "Mundo!";

   System.out.println(TEXTO1.concat(TEXTO2));
   System.out.println(TEXTO1 + TEXTO2); 

  }
}
