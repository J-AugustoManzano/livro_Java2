class C07EX06 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.sin(30 * Math.toRadians(1)));
    System.out.println(Math.sin(Math.PI / 6));    
    System.out.println(Math.sin(1)); 
    System.out.println(Math.sin(Math.PI / 3)); 

  }
}

