class C07EX02 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.asin(-1));                  
    System.out.println(Math.asin(1));    
    System.out.println(Math.asin(0.5)); 
    System.out.println(Math.asin(0.5) * 180 / Math.PI); 
    System.out.println(Math.toDegrees(Math.asin(0.5))); 

  }
}

