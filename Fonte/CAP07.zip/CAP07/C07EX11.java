class C07EX11 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.log(3));                  
    System.out.println(Math.log(Math.exp(10)));                  
    System.out.println(Math.log(2.0));                  

  }
}

