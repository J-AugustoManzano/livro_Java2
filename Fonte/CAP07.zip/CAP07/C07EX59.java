import java.io.*;
class C07EX59 {
  public static void main(String args[]) {

    boolean LOGICO = true;
    int INTEIRO;

    INTEIRO = (LOGICO)?1:0;

    System.out.println();
    System.out.println("Valor verdadeiro de LOGICO ...: " + LOGICO);
    System.out.println("Valor verdadeiro de INTEIRO ..: " + INTEIRO);
    System.out.println();
    
  }
}
