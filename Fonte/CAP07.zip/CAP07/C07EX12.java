class C07EX12 {
  public static void main(String args[]) {

    System.out.println();
    System.out.println(Math.abs(-8.238765));                  
    System.out.println(Math.abs(-9));    

  }
}

