import java.io.*;
class C07EX51 {
  public static void main(String args[]) {

    int INTEIRO = 10;
    String STR;

    STR = Integer.toString(INTEIRO);

    System.out.println();
    System.out.print("Valor = " + STR);
    System.out.println();
    
  }
}
