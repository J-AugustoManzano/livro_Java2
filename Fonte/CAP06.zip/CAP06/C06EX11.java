import java.io.*;
class C06EX11 {
  public static void main(String args[]) {

    System.out.println();

    for (int I = 1; I <= 10; I += 2)
      System.out.println("Valor = " + I);

  }
}
