import java.io.*;
class C06EX01 {
  public static void main(String args[]) {

    int I;
    System.out.println();

    I = 1;
    while (I <= 5)
      {
        System.out.println("Valor = " + I);
        I = I + 1;
      }

  }
}
