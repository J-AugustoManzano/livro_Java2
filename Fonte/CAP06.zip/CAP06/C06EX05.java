import java.io.*;
class C06EX05 {
  public static void main(String args[]) {

    int I;
    System.out.println();

    I = 1;
    do
      {
        System.out.println("Valor = " + I);
        I++;
      }
    while (I <= 5);

  }
}
