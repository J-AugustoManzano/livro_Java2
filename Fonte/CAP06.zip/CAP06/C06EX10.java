import java.io.*;
class C06EX10 {
  public static void main(String args[]) {

    System.out.println();

    for (int I = 5; I >= 1; I--)
      System.out.println("Valor = " + I);

  }
}
