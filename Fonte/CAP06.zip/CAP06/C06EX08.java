import java.io.*;
class C06EX08 {
  public static void main(String args[]) {

    int I;
    System.out.println();

    for (I = 1; I <= 5; I++)
      System.out.println("Valor = " + I);

  }
}
