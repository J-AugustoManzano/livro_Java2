import javax.swing.JOptionPane;
class AloMundo2 {
  public static void main(String args[]) {
    JOptionPane.showMessageDialog(null, "Alo, Mundo\nEstudo de Programacao com Java");
    System.exit( 0 );
  }
}
