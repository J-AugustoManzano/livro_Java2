import java.awt.Graphics;
public class AloMundo3 extends java.applet.Applet {
  public void paint(Graphics g) {
    g.drawString("Alo, Mundo", 1, 15);
    g.drawString("Estudo de Programacao com Java", 1, 30);
  }
}
