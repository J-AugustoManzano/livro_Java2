class AloMundo {
  public static void main(String args[]) {
    System.out.println("Alo, Mundo ");
    System.out.println("Estudo de Programacao com Java ");
  }
}


